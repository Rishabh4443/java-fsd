package mphasis;
import java.util.Scanner;
public class EmailSearchProgram {

	public static void main(String[] args) {
        // Array of employee email IDs
        String[] employeeEmails = {
            "rishabhsaxena374@gmail.com",
            "jigyanshu@gmail.com",
            "lucky123@gmail.com",
            // Add more email IDs as needed
        };

        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an email ID
        System.out.print("Enter the email ID to search: ");
        String userInput = scanner.nextLine();

        // Call the searchEmail method to check if the entered email ID is in the array
        boolean isEmailFound = searchEmail(userInput, employeeEmails);

        // Display the result
        if (isEmailFound) {
            System.out.println("Email ID found in the list.");
        } else {
            System.out.println("Email ID not found in the list.");
        }

        // Close the Scanner
        scanner.close();
    }

    // Method to search for an email ID in an array
    public static boolean searchEmail(String targetEmail, String[] emailArray) {
        for (String email : emailArray) {
            if (email.equals(targetEmail)) {
                return true; // Email ID found
            }
        }
        return false; // Email ID not found
    }
}
